


/**
 *
 * @author aleja
 */
public class Curso {

  
    public static void main(String[] args) {
        
        EstudianteUni estudiante=new EstudianteUni("Alejandro","7590-24-1906",60);
        System.out.println("El estudiante: "+estudiante.getNombre()+ ", con el numero de carnet: "+estudiante.getCarnet());
        estudiante.setNotaFinal(61);
        
        
        EstudianteUni estudiante1=new EstudianteUni("Jose","123456789",61);
        System.out.println("El estudiante: "+estudiante1.getNombre()+ ", con el numero de carnet: "+estudiante1.getCarnet());
        estudiante.setNotaFinal(60);
    }
}

