
/**
 *
 * @author aleja
 */
public class EstudianteUni {
    
   private String Nombre;
   private String Carnet; 
  private int NotaFinal;

    public EstudianteUni(String Nombre, String Carnet, int NotaFinal) {
        this.Nombre = Nombre;
        this.Carnet = Carnet;
        this.NotaFinal = NotaFinal;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCarnet() {
        return Carnet;
    }

    public void setCarnet(String Carnet) {
        this.Carnet = Carnet;
    }

    public int getNotaFinal() {
        return NotaFinal;
    }

    public void setNotaFinal(int NotaFinal) {
        
        if(NotaFinal<61 && NotaFinal>=0){
            System.out.println("No ha sido promovido");
        this.NotaFinal=NotaFinal;
    }else{
        System.out.println("Ha sido promovido");
    }
       
}
    
  
    }
