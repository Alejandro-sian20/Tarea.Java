
package producto;


 /**
 *
 * @author aleja
 */
public class Producto {

   private int codigo;
   private String nombre; 
   private double precio;

    public Producto(int Codigo, String Nombre, double Precio) {
        this.codigo = Codigo;
        this.nombre = Nombre;
        this.precio = Precio;
    }
    
    
   
    public static void main(String[] args) {
      
        Producto producto1= new Producto(101,"Caja de galletas",50.00);
        

        producto1.setPrecio(100);//aqui se le asigna el nuevo precio al producto.
      
         
        
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int Codigo) {
        this.codigo = Codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double Precio) {
        
        if(Precio<0){
        System.out.println("precio no valido: ");
        }else{
        this.precio = Precio;
        System.out.println("el producto"+",Codigo: " +codigo + ", nombre:"+nombre + ",tiene un nuevo precio de :"+precio );
        }
    }
    
    
    
}
