package sistemabancario;

/**
 *
 * @author aleja
 */
public class CuentaBancaria {
    
    private String numeroCuenta;
    private double saldo;
    private Cliente propietario;

    // Constructor
    public CuentaBancaria(String numeroCuenta, double saldo, Cliente propietario) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.propietario = propietario;
    }

    // Getters y Setters
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        if (saldo >= 0) {
            this.saldo = saldo;
        } else {
            System.out.println("El saldo no puede ser negativo.");
        }
    }

    public Cliente getPropietario() {
        return propietario;
    }

    public void setPropietario(Cliente propietario) {
        if (propietario != null) {
            this.propietario = propietario;
        } else {
            System.out.println("El propietario no puede ser nulo.");
        }
    }

    // Método para depositar dinero
    public void depositar(double monto) {
        if (monto > 0) {
            saldo += monto;
        } else {
            System.out.println("La cantidad a depositar debe ser positiva.");
        }
    }

    // Método para retirar dinero
    public void retirar(double monto) {
        if (monto > 0) {
            if (monto <= saldo) {
                saldo -= monto;
            } else {
                System.out.println("Fondos insuficientes.");
            }
        } else {
            System.out.println("La cantidad a retirar debe ser positiva.");
        }
    }

    // Método para consultar saldo
    public double consultar() {
        return saldo;
    }

    
    @Override
    public String toString() {
        return "CuentaBancaria: " +
                "numeroCuenta: " + numeroCuenta +
                ", saldo: " + saldo +
                ", propietario: " + propietario 
                ;
    }
    
    
}
    
    
    
    
   

