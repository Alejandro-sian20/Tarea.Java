package sistemabancario;

import java.util.ArrayList;
import java.util.List;

public class Banco {
    private List<CuentaBancaria> cuentas;

    // Constructor
    public Banco() {
        this.cuentas = new ArrayList<>();
    }

    // Método para agregar una cuenta
    public void agregarCuenta(CuentaBancaria cuenta) {
        if (cuenta != null) {
            cuentas.add(cuenta);
        } else {
            System.out.println("No se puede agregar una cuenta nula.");
        }
    }

    // Método para obtener todas las cuentas
    public List<CuentaBancaria> getCuentas() {
        return cuentas;
    }

  

    // Método para mostrar todas las cuentas
    public void mostrarCuentas() {
        for (CuentaBancaria cuenta : cuentas) {
            System.out.println(cuenta);
        }
    }
}