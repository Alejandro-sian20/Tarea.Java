/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemabancario;

/**
 *
 * @author aleja
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear un cliente
        Cliente cliente1 = new Cliente("Alejandro Sian", "3039576540110", "San Juan Sacatepequez");

        // Mostrar los datos del cliente
        System.out.println(" Datos del Cliente ");
        cliente1.mostrarDatos();
        System.out.println(); // Salto de línea

        CuentaBancaria cuenta1 = new CuentaBancaria("48450554", 300.50, cliente1);

        System.out.println(" Saldo Inicial ");
        System.out.println("El saldo actual es de: " + cuenta1.getSaldo());
        System.out.println(); // Salto de línea

        System.out.println(" Depósito ");
        double montoDeposito = 500.0;
        System.out.println("Depositando: " + montoDeposito);
        cuenta1.depositar(montoDeposito);
        System.out.println("Saldo después de depositar: " + cuenta1.consultar());
        System.out.println(); 

        System.out.println(" Retiro ");
        double montoRetiro = 30.00;
        System.out.println("Intentando retirar: " + montoRetiro);
        cuenta1.retirar(montoRetiro);
        System.out.println("Saldo después de retirar: " + cuenta1.consultar());
        System.out.println(); 

        
        Banco banco = new Banco();
        banco.agregarCuenta(cuenta1);

        
        System.out.println(" Cuentas en el Banco ");
        banco.mostrarCuentas();
        System.out.println(); 

        
        
    }
}
    
    

