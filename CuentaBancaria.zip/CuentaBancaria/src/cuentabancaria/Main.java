
package cuentabancaria;

/**
 *
 * @author aleja
 */
public class Main {
     public static void main(String[] args) { //punto incial del programa
        
        CuentaBancaria cuenta = new CuentaBancaria("48450554", 1000.0);

        // Depositar dinero
        cuenta.depositar(500.0);
        System.out.println("Saldo después de depositar: " + cuenta.consultarSaldo());

        // Retirar dinero
        cuenta.retirar(200.0);
        System.out.println("Saldo después de retirar: " + cuenta.consultarSaldo());

        // Intentar retirar más dinero del disponible
        cuenta.retirar(1500.0);
        System.out.println("Saldo después de intentar retirar más del disponible: " + cuenta.consultarSaldo());
    }
}
    
