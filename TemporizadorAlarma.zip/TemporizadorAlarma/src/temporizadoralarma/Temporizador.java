/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temporizadoralarma;

/**
 *
 * @author aleja
 */
public class Temporizador {
    
    private int tiempoActual;
    private Alarma alarma;
    
    public Temporizador(){
        this.tiempoActual = 0;
        
    }

    public int getTiempoActual(){
        return tiempoActual;
    }

    public void iniciar() {
        while (true) {
            tiempoActual++;
            System.out.println("Tiempo actual: " + tiempoActual + " segundos");

            if (alarma != null && alarma.debeActivarse(tiempoActual)) {
                System.out.println("El tiempo ha finalizado");
                break;
            }

            try {
                Thread.sleep(1000); // Esperar 1 segundo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Método para asociar una alarma
    public void asociarAlarma(Alarma alarma) {
        this.alarma = alarma;
    }
 
    }
    
    

