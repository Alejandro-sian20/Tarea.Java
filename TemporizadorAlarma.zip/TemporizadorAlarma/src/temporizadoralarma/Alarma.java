/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temporizadoralarma;

/**
 *
 * @author aleja
 */
public class Alarma {
    private int tiempoObjetivo;
    
    public Alarma(int tiempoObjetivo){
        this.tiempoObjetivo = tiempoObjetivo;
    }
    public int getAlarma(){
        return tiempoObjetivo;
    }
    
    public boolean debeActivarse(int tiempoActual) {
        return tiempoActual >= tiempoObjetivo;
}
}
